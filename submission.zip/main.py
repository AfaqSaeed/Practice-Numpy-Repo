from pattern import Checker,Circle,Spectrum
from generator import ImageGenerator

